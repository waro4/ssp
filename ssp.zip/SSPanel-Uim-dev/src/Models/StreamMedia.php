<?php
namespace App\Models;

class StreamMedia extends Model
{
    protected $connection = 'default';
    protected $table = 'stream_media';
}
