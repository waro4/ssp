<?php


namespace App\Models;

class NodeOnlineLog extends Model
{
    protected $connection = 'default';
    protected $table = 'node_online_log';
}
