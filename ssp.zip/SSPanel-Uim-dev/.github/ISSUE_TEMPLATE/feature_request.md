---
name: Feature request
about: Suggest an new idea for this project
title: "[Feature Request]"
labels: enhancement

---

- [ ] I certify that I have read project Wiki and other issue may related to this one.
- [ ] I acknowledge I have to replace [ ] with [x]. If I leave any space before or after x, my issue could be closed without any notice.

**Feature**
The feature you want.

**Solution**
If you have some solution about this issue, type it here.

**Addition**
Additional context here.
