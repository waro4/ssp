ALTER TABLE user_hourly_usage MODIFY traffic bigint(20);
ALTER TABLE user_hourly_usage MODIFY hourly_usage bigint(20);
